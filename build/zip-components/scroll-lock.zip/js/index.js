import {ScrollLock} from './scroll-lock';
